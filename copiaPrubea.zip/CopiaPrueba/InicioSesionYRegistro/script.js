const $btnSignIn= document.querySelector('.sign-in-btn'),
      $btnSignUp = document.querySelector('.sign-up-btn'),  
      $signUp = document.querySelector('.sign-up'),
      $signIn  = document.querySelector('.sign-in');

document.addEventListener('click', e => {
    if (e.target === $btnSignIn || e.target === $btnSignUp) {
        $signIn.classList.toggle('active');
        $signUp.classList.toggle('active')
    }
});

// Función para obtener publicaciones
async function obtenerPublicaciones() {
    try {
        const response = await fetch('http://localhost:3000/api/publicaciones');
        if (!response.ok) {
            throw new Error('Error en la red');
        }
        const data = await response.json();
        const contenedor = document.getElementById('publicaciones');
        contenedor.innerHTML = '';  // Limpiamos el contenedor

        // Mostramos las publicaciones en la página
        data.forEach(publicacion => {
            const div = document.createElement('div');
            div.innerHTML = `<strong>${publicacion.NombreClub}</strong>: Colores: ${publicacion.ColoresDelClub}, Creador: ${publicacion.UsuarioCreador}`;
            contenedor.appendChild(div);
        });
    } catch (error) {
        console.error('Error al obtener las publicaciones:', error);
    }
}

// Función para obtener publicaciones
function obtenerPublicaciones() {
    fetch('http://localhost:3000/api/publicaciones')
      .then(response => response.json())
      .then(data => {
        const contenedor = document.getElementById('publicaciones');
        contenedor.innerHTML = '';  // Limpiamos el contenedor
  
        // Mostramos las publicaciones en la página
        data.forEach(publicacion => {
          const div = document.createElement('div');
          div.innerHTML = `<strong>${publicacion.NombreClub}:</strong> Colores: ${publicacion.ColoresDelClub}, Creador: ${publicacion.UsuarioCreador}`;
          contenedor.appendChild(div);
        });
      })
      .catch(error => console.error('Error al obtener las publicaciones:', error));
  }
  
  // Función para registrar un nuevo club
function registrarClub() {
    const NombreClub = document.getElementById('nombreClub').value;
    const ColoresDelClub = document.getElementById('coloresClub').value;
    const UsuarioCreador = document.getElementById('usuarioCreador').value;
    const Constraseña = document.getElementById('contrasena').value;

    fetch('http://localhost:3000/api/publicaciones', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            NombreClub,
            ColoresDelClub,
            UsuarioCreador,
            Constraseña,
        }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la solicitud: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Club registrado:', data);
        obtenerPublicaciones(); // Vuelve a cargar las publicaciones
    })
    .catch(error => console.error('Error al registrar el club:', error));
}

// Llama a la función al cargar la página
obtenerPublicaciones();

// Asigna el evento al botón de registro
document.getElementById('registrarBtn').addEventListener('click', registrarClub);

  

  