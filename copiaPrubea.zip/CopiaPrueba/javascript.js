//import express from 'express'; // Asegúrate de que estás usando "type": "module" en package.json
//import cors from 'cors';
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json()); // Para permitir recibir JSON si es necesario

// Datos de prueba de clubes
const publicaciones = [
  { id: 1, NombreClub: 'LosAngelesDelInfierno', ColoresDelClub: 'Negro', UsuarioCreador: 'Carlos', Constraseña: '1234'},
  { id: 2, NombreClub: 'Road Owners', ColoresDelClub: 'RojoYBlanco', UsuarioCreador: 'Sergio', Constraseña: '4321' },
  { id: 3, NombreClub: 'Real Bikers', ColoresDelClub: 'Azul', UsuarioCreador: 'Eduardo', Constraseña: '2121'},
  { id: 4, NombreClub: 'Spanish Riders', ColoresDelClub: 'NegroYRojo', UsuarioCreador: 'Ruben', Constraseña: '1212'},
];

/*// Configura el endpoint
app.get('/api/publicaciones', (req, res) => {
  res.json(publicaciones);
});

// Inicia el servidor
app.listen(PORT, () => {
  console.log(`Servidor en ejecución en http://localhost:${PORT}`);
});*/


// Configura el endpoint para obtener publicaciones
app.get('/api/publicaciones', (req, res) => {
  res.json(publicaciones);
});

// Configura el endpoint para registrar un nuevo club
app.post('/api/publicaciones', (req, res) => {
  const { NombreClub, ColoresDelClub, UsuarioCreador, Constraseña } = req.body;

  if (!NombreClub || !ColoresDelClub || !UsuarioCreador || !Constraseña) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  const nuevaPublicacion = {
    id: publicaciones.length + 1, // Generar un nuevo ID
    NombreClub,
    ColoresDelClub,
    UsuarioCreador,
    Constraseña,
  };

  publicaciones.push(nuevaPublicacion);
  res.status(201).json(nuevaPublicacion);
});

// Inicia el servidor
app.listen(PORT, () => {
  console.log(`Servidor en ejecución en http://localhost:${PORT}`);
});






 // Función para obtener publicaciones
 function obtenerPublicaciones() {
  fetch('http://localhost:3000/api/publicaciones')
  .then(response => response.json())
  .then(data => {
      const contenedor = document.getElementById('publicaciones');
      contenedor.innerHTML = '';  // Limpiamos el contenedor

      // Mostramos las publicaciones en la página
      data.forEach(publicacion => {
          const div = document.createElement('div');
          div.innerHTML = `<strong>${publicacion.NombreClub}:</strong> Colores: ${publicacion.ColoresDelClub}, Creador: ${publicacion.UsuarioCreador}`;
          contenedor.appendChild(div);
      });
  })
  .catch(error => console.error('Error al obtener las publicaciones:', error));
}

